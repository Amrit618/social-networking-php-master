<?php
error_reporting(E_ALL ^ E_NOTICE);

error_reporting(E_ALL ^ E_NOTICE);
error_reporting(E_ALL ^ E_DEPRECATED);
mysql_connect('localhost','root','');
mysql_select_db('friend_system');
error_reporting(E_ALL ^ E_DEPRECATED);

?>


