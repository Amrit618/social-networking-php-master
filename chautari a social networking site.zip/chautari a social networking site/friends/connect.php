<?php

mysql_connect('localhost','root','');
mysql_select_db('friend_system');

?>