<!DOCTYPE html>
<html>
<head>
	<title>profile</title>
</head>
<body>
<link rel='stylesheet' href='../style/style.css'> 

<?php include 'connect.php' ?>
<?php include '../header/header.php' ?>
<div class='container'>
<?php

echo"friend request accepted";




?>
</form>
</div>
